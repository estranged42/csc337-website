<?php

class APITests extends PHPUnit_Framework_TestCase
{

    private $urlbase = "http://52.35.157.11/hw6/server.php";
    private $ch = null;
    private $headers = null;

    /**
     * testNoCommand
     *
     * This set of tests is to see if you are properly returning JSON, and that the JSON
     * you return contains an error key with the correct error message.  The HTTP response
     * code should be set to 400.
     */
    public function testNoCommand() {
        $command = $this->urlbase . "?";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("no command found", $responseJson->error);
    }

    /**
     * testStatsCommand
     *
     * This set of tests is to see if you are correctly returning the stats information for
     * the stats command. Order of the stats keys does not matter, just that the 4 different
     * stats are returned as part of the data object.
     */
    public function testStatsCommand() {
        $command = $this->urlbase . "?cmd=stats";
        $responseJson = $this->apiCall($command, 200);
        $this->assertEquals("stats", $responseJson->message);
        $this->assertTrue( isset($responseJson->data), 'data key not present' );
        $this->assertTrue( isset($responseJson->data->switchWins), 'data->switchWins key not present' );
        $this->assertTrue( isset($responseJson->data->switchLoss), 'data->switchLoss key not present' );
        $this->assertTrue( isset($responseJson->data->noSwitchWins), 'data->noSwitchWins key not present' );
        $this->assertTrue( isset($responseJson->data->noSwitchLoss), 'data->noSwitchLoss key not present' );
    }


    /**
     * testNewGameCommand
     *
     * This set of tests is to see if you are properly handling a newGame command. You should
     * be returning 4 keys in your data response, but only the game_id should have a value. 
     * The others should be null.
     */
    public function testNewGameCommand() {
        $command = $this->urlbase . "?cmd=newGame";
        $responseJson = $this->apiCall($command, 200);
        $this->assertEquals("new game created", $responseJson->message);
        
        $this->assertTrue( isset($responseJson->data), 'data key not present' );
        $this->assertTrue( isset($responseJson->data->game_id), 'data->game_id key not present' );
        $this->assertTrue( is_numeric($responseJson->data->game_id), 'data->game_id should be a number' );

        $this->assertNull( $responseJson->data->opened_door, 'data->opened_door should be null' );
        $this->assertNull( $responseJson->data->initial_selected, 'data->initial_selected should be null' );
        $this->assertNull( $responseJson->data->final_selected, 'data->final_selected key should be null' );
    }

    /**
     * testfirstChoice
     *
     * This set of tests is to see if you handle a correct firstChoice command. The new bit of
     * data returned in this command will be the door to open.
     */
    public function testfirstChoice() {
        $command = $this->urlbase . "?cmd=newGame";
        $responseJson = $this->apiCall($command, 200);
        $gameID = $responseJson->data->game_id;

        $command = $this->urlbase . "?cmd=firstChoice&game_id={$gameID}&choice=2";
        $responseJson = $this->apiCall($command, 200);
        $this->assertEquals("opened door", $responseJson->message);
        
        $this->assertTrue( isset($responseJson->data), 'data key not present' );
        $this->assertTrue( isset($responseJson->data->game_id), 'data->game_id key not present' );
        $this->assertTrue( is_numeric($responseJson->data->game_id), 'data->game_id should be a number' );

        $this->assertEquals( '2', $responseJson->data->initial_selected, 'data->initial_selected should be 2' );
        $this->assertTrue( is_numeric($responseJson->data->opened_door), 'data->opened_door should be a number' );
        $this->assertNull( $responseJson->data->final_selected, 'data->final_selected key should be null' );
        
        $this->gameID = $responseJson->data->game_id;
    }

    /**
     * testfirstChoiceErrors
     *
     * There are lots of ways to issue an incorrect newGame command.  Make sure you are 
     * returning good errors for known bad commands.
     */
    public function testfirstChoiceErrors() {
        $command = $this->urlbase . "?cmd=newGame";
        $responseJson = $this->apiCall($command, 200);
        $gameID = $responseJson->data->game_id;

        $command = $this->urlbase . "?cmd=firstChoice";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("game_id parameter is required", $responseJson->error);

        $command = $this->urlbase . "?cmd=firstChoice&game_id={$gameID}";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("choice parameter is required", $responseJson->error);
        
        $command = $this->urlbase . "?cmd=firstChoice&game_id=ABCD&choice=0";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("game_id must be an integer", $responseJson->error);

        $command = $this->urlbase . "?cmd=firstChoice&game_id={$gameID}&choice=ABCD";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("choice must be an integer", $responseJson->error);

        $command = $this->urlbase . "?cmd=firstChoice&game_id=9999999999&choice=0";
        $responseJson = $this->apiCall($command, 404);
        $this->assertEquals("no matching game found", $responseJson->error);
    }

    /**
     * testFinalChoice
     *
     * This set of tests is to see if you handle a correct finalChoice command. All the 
     * data fields will be returned in this command's data response, including the prize
     * door. Be sure to run this a few times to make sure you are passing both win and
     * loose conditions.
     */
    public function testFinalChoice() {
        // Make a new Game
        $command = $this->urlbase . "?cmd=newGame";
        $responseJson = $this->apiCall($command, 200);
        $gameID = $responseJson->data->game_id;

        // Make your first choice
        $command = $this->urlbase . "?cmd=firstChoice&game_id={$gameID}&choice=1";
        $responseJson = $this->apiCall($command, 200);
        $this->assertEquals("opened door", $responseJson->message);
        
        $this->assertTrue( isset($responseJson->data), 'data key not present' );
        $this->assertTrue( isset($responseJson->data->game_id), 'data->game_id key not present' );
        $this->assertTrue( is_numeric($responseJson->data->game_id), 'data->game_id should be a number' );

        $this->assertEquals( '1', $responseJson->data->initial_selected, 'data->initial_selected should be 1' );
        $this->assertTrue( is_numeric($responseJson->data->opened_door), 'data->opened_door should be a number' );
        $this->assertNull( $responseJson->data->final_selected, 'data->final_selected key should be null' );
        
        $openedDoor = $responseJson->data->opened_door;
        
        // Make your final choice (switch)
        if ($openedDoor == 0) {
            $finalDoor = 2;
        } else {
            $finalDoor = 0;
        }
        $command = $this->urlbase . "?cmd=finalChoice&game_id={$gameID}&choice={$finalDoor}";
        $responseJson = $this->apiCall($command, 200);

        $this->assertEquals( '1', $responseJson->data->initial_selected, 'data->initial_selected should be 1' );
        $this->assertEquals( $finalDoor, $responseJson->data->final_selected, "data->final_selected should be {$finalDoor}" );
        $this->assertTrue( is_numeric($responseJson->data->prize_door), 'data->prize_door should be a number' );
        
        $prizeDoor = $responseJson->data->prize_door;
        
        if ($finalDoor == $prizeDoor) {
            $this->assertEquals("you won", $responseJson->message);
        } else {
            $this->assertEquals("you lost", $responseJson->message);
        }
    }

    /**
     * testfinalChoiceErrors
     *
     * Just like the firstChoice command, there are lots of potential invalid finalChoice commands
     * that could be sent. Be sure your API is returning good errors for known bad commands.
     */
    public function testfinalChoiceErrors() {
        $command = $this->urlbase . "?cmd=newGame";
        $responseJson = $this->apiCall($command, 200);
        $gameID = $responseJson->data->game_id;
        $command = $this->urlbase . "?cmd=firstChoice&game_id={$gameID}&choice=1";
        $responseJson = $this->apiCall($command, 200);
        $this->assertEquals("opened door", $responseJson->message);
        $openedDoor = $responseJson->data->opened_door;

        $command = $this->urlbase . "?cmd=finalChoice";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("game_id parameter is required", $responseJson->error);

        $command = $this->urlbase . "?cmd=finalChoice&game_id={$gameID}";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("choice parameter is required", $responseJson->error);
        
        $command = $this->urlbase . "?cmd=finalChoice&game_id=ABCD&choice=1";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("game_id must be an integer", $responseJson->error);

        $command = $this->urlbase . "?cmd=finalChoice&game_id={$gameID}&choice=ABCD";
        $responseJson = $this->apiCall($command, 400);
        $this->assertEquals("choice must be an integer", $responseJson->error);

        $command = $this->urlbase . "?cmd=finalChoice&game_id=9999999999&choice=1";
        $responseJson = $this->apiCall($command, 404);
        $this->assertEquals("no matching game found", $responseJson->error);

        $command = $this->urlbase . "?cmd=finalChoice&game_id={$gameID}&choice={$openedDoor}";
        $responseJson = $this->apiCall($command, 409);
        $this->assertEquals("cannot choose opened door", $responseJson->error);
    }

    /**
     * apiCall
     *
     * This is a wrapper for everything that needs to happen for each API call. This method
     * sets up all the headers for the request, and examines the response to look for common
     * errors.  All responses should be well formed JSON.  The expected HTTP response code
     * is passed in as a method argument, and tested against the actual response code.
     */
    private function apiCall($command, $expectedCode) {
    
        $this->ch = curl_init();                                                                      
        curl_setopt($this->ch, CURLOPT_URL, $command);

        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_VERBOSE, 1);
        curl_setopt($this->ch, CURLINFO_HEADER_OUT, true);

        $header = array( "Expect:" );
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
        
        $this->headers = array();
        curl_setopt($this->ch, CURLOPT_HEADERFUNCTION, array($this, "storeHeaders") );
        
        $rawResponse = curl_exec($this->ch);
        $error = curl_error($this->ch);
        $this->assertEquals("", $error);

        $responseCode = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
        $this->assertEquals($expectedCode, $responseCode, "Expected HTTP respose code {$expectedCode}");
        
        $this->assertArrayHasKey('Content-Type', $this->headers);
        $this->assertStringStartsWith('text/json', $this->headers['Content-Type']);

        $responseJson = json_decode($rawResponse);
        $this->assertNotEquals(null, $responseJson);

        return $responseJson;
    }
    
    /**
     * storeHeaders
     *
     * This is a callback function that cURL calls when the response comes. It parses out 
     * all the headers and stores them on the object for later use.
     * See: http://php.net/manual/en/function.curl-setopt.php#52675
     */
    private function storeHeaders($ch, $line) {
        if (strpos($line, ": ") !== false) {
            list($field, $val) = explode(": ", $line);
            $val = trim($val);
            $this->headers[$field] = $val;
        }
        return strlen($line);
    }

}
